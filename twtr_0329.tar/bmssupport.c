/*--------------File Info---------------------------------------------------------------------------------
** File name:           bmssupport.c
** Last modified Date:  2012-07-5
** Last Version:        V1.0
** Descriptions:        ���� BMS ���ִ��綯
*********************************************************************************************************/
#include "LPC17xx.h"
#include "string.h"  
#include "..\USER_CODE\sim900.h" 
#include "..\USER_CODE\LPC1700CAN.h"
#include "..\USER_CODE\main.h"
#include "..\USER_CODE\bwtcfg.h"
#include "..\USER_CODE\uart.h"
#include "..\USER_CODE\ritimer.h"
#include "..\USER_CODE\utility.h"
#include "..\USER_CODE\bmssupport.h"
#include "..\MX25L1602Drv\MX25L1602Drv.h"

extern unsigned long   NomalVtg; 
extern unsigned short  NomTemp;


extern MessageDetail MessageCAN0;


// ���1S��Ϣ
extern BAT1S_INFO g_sBat1SInfo;

//������Ϣ
extern CELL_INFO g_sCellInfo;

// GPS ��Ϣ
extern GPS_INFO g_sGPSInfo;

// ��ֵ��Ϣ
extern EXTRM_INFO g_sExtremInfo;

// ������Ϣ
extern CAR_INFO g_sCarInfo;




unsigned short Cell_Vtg1,Cell_Vtg2,Cell_Vtg3,Cell_Vtg4;

unsigned short CaseEndable[9] = {0,40,80,120,160,200,248,296,336};// 8 





/*********************************************************************************************************
** Function name:       CanDataDeal
** Descriptions:        Can���ݴ���
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void CanDataDeal(void)
{

	unsigned long 	CanID;
	unsigned short  index;
	unsigned long   Mileage,Energy;
	unsigned char   CurrentCase;

	//
	// ������������ e-Power ����ϵͳ
   	//
   	if(MessageCAN0.CANID == 0x104C1865)	 // ��ȡ�ܵ�ѹ���ܵ�����SOC
   	{
		//index = ((MessageCAN0.DATA[0] * 256 + MessageCAN0.DATA[1]) / 10 );
		g_sExtremInfo.TotalVtg[0] = MessageCAN0.DATA[1];
		g_sExtremInfo.TotalVtg[1] = MessageCAN0.DATA[0];  // ��ȡ�ܵ�ѹ

		// 1S
		g_sBat1SInfo.TotalVtg[0] = MessageCAN0.DATA[1];
		g_sBat1SInfo.TotalVtg[1] = MessageCAN0.DATA[0];  // ��ȡ�ܵ�ѹ

		index = ((MessageCAN0.DATA[3] * 256 + MessageCAN0.DATA[2]) ) + 3200;
       	g_sExtremInfo.TotalAmp[0] = (unsigned char)(index >> 8);
		g_sExtremInfo.TotalAmp[1] = (unsigned char)index;   // ��ȡ�ܵ���
       	//g_ucSOC = (MessageCAN0.DATA[4]) * 4 / 10;// ��ȡ SOC

       	//1S
		g_sBat1SInfo.TotalAmp[0] = (unsigned char)(index >> 8);
		g_sBat1SInfo.TotalAmp[1] = (unsigned char)index;   // ��ȡ�ܵ���


		g_sExtremInfo.SOC[0] = 0x00;
		g_sExtremInfo.SOC[1] = MessageCAN0.DATA[7] * 4 / 10;

       	//1S
		g_sBat1SInfo.SOC[0] = 0x00;
		g_sBat1SInfo.SOC[1] = MessageCAN0.DATA[7] * 4 / 10;  // ��ȡSOC
   	}

            
	//  
	// ��ؼ�ֵ��Ϣ e-Power ����ϵͳ
	//
	if(MessageCAN0.CANID == 0x104C1866)	 // ��ȡ��ֵ��ѹ��Ϣ
   	{
		g_sExtremInfo.MaxVtgCell[2] =  MessageCAN0.DATA[1];
		g_sExtremInfo.MaxVtgCell[3] =  MessageCAN0.DATA[0];
		g_sExtremInfo.MaxVtgCell[0] =  MessageCAN0.DATA[2];						 
		g_sExtremInfo.MaxVtgCell[1] =  MessageCAN0.DATA[3];

		g_sExtremInfo.MinVtgCell[2] =  MessageCAN0.DATA[5];
		g_sExtremInfo.MinVtgCell[3] =  MessageCAN0.DATA[4];
		g_sExtremInfo.MinVtgCell[0] =  MessageCAN0.DATA[6];
		g_sExtremInfo.MinVtgCell[1] =  MessageCAN0.DATA[7];
   	}

	//
	// ��ȡ������¶� e-Power ����ϵͳ
  	//
	if(MessageCAN0.CANID == 0x104C1867)	 // ��ȡ��ֵ�¶���Ϣ
   	{
   		g_sExtremInfo.MaxTemp[1]  = MessageCAN0.DATA[0];
		g_sExtremInfo.MaxTemp[0] = 0;
		g_sExtremInfo.MaxTemp[0] |= (MessageCAN0.DATA[1]) << 3;
		g_sExtremInfo.MaxTemp[0] |= (1 & 0x07);   
				
		g_sExtremInfo.MinTemp[1]  = MessageCAN0.DATA[2];
		g_sExtremInfo.MinTemp[0] = 0;
		g_sExtremInfo.MinTemp[0] |= (MessageCAN0.DATA[3]) << 3;
		g_sExtremInfo.MinTemp[0] |= (1 & 0x07);			
	}

	//wj:add to get total Mileage
	if(MessageCAN0.CANID == 0x18FFD017)	 //�����
    {
		Mileage = 	(unsigned long)(MessageCAN0.DATA[7] << 24) |  
					(unsigned long)(MessageCAN0.DATA[6] << 16) |  
					(unsigned long)(MessageCAN0.DATA[5] << 8) |  
					(unsigned long)(MessageCAN0.DATA[4]);
		Mileage = Mileage *5 /1000;
		g_sBat1SInfo.Mileage[0]  = (unsigned char)(Mileage >> 24);
		g_sBat1SInfo.Mileage[1]  = (unsigned char)(Mileage >> 16);
		g_sBat1SInfo.Mileage[2]  = (unsigned char)(Mileage >> 8);
		g_sBat1SInfo.Mileage[3]  = (unsigned char)(Mileage);

 		g_sCarInfo.Mileage[0]  = (unsigned char)(Mileage >> 24);
		g_sCarInfo.Mileage[1]  = (unsigned char)(Mileage >> 16);
		g_sCarInfo.Mileage[2]  = (unsigned char)(Mileage >> 8);
		g_sCarInfo.Mileage[3]  = (unsigned char)(Mileage);

	}
    
    

	//
	// ������Ϣ 1
	//
	if(MessageCAN0.CANID == 0x104C1864)	
   	{

		Mileage = 	(unsigned long)(MessageCAN0.DATA[3] << 24) |  
					(unsigned long)(MessageCAN0.DATA[2] << 16) |  
					(unsigned long)(MessageCAN0.DATA[1] << 8) |  
					(unsigned long)(MessageCAN0.DATA[0]); 
					
		Mileage = Mileage / 10;		

   		g_sCarInfo.Mileage[0]  = (unsigned char)(Mileage >> 24);
		g_sCarInfo.Mileage[1]  = (unsigned char)(Mileage >> 16);
		g_sCarInfo.Mileage[2]  = (unsigned char)(Mileage >> 8);
		g_sCarInfo.Mileage[3]  = (unsigned char)(Mileage);

	   	g_sBat1SInfo.Mileage[0]  = (unsigned char)(Mileage >> 24);
		g_sBat1SInfo.Mileage[1]  = (unsigned char)(Mileage >> 16);
		g_sBat1SInfo.Mileage[2]  = (unsigned char)(Mileage >> 8);
		g_sBat1SInfo.Mileage[3]  = (unsigned char)(Mileage);
			
		Energy = 	(unsigned long)(MessageCAN0.DATA[7] << 24) |  
					(unsigned long)(MessageCAN0.DATA[6] << 16) |  
					(unsigned long)(MessageCAN0.DATA[5] << 8) |  
					(unsigned long)(MessageCAN0.DATA[4]); 
					
		Energy = Energy / 10;		

   		g_sCarInfo.Energy[0]  = (unsigned char)(Energy >> 24);
		g_sCarInfo.Energy[1]  = (unsigned char)(Energy >> 16);
		g_sCarInfo.Energy[2]  = (unsigned char)(Energy >> 8);
		g_sCarInfo.Energy[3]  = (unsigned char)(Energy);			
	}

	//
	// ������Ϣ 2
	//
	if(MessageCAN0.CANID == 0x18FEF1A6)	
   	{
		// �ٶ�
		g_sCarInfo.Speed = MessageCAN0.DATA[0];
		g_sBat1SInfo.Speed = MessageCAN0.DATA[0]/2;
				
		// ʣ�����
		g_sCarInfo.ReMileage[0] = 0; 
		g_sCarInfo.ReMileage[1] = MessageCAN0.DATA[1];
		
		// ��Ե����
		index = (MessageCAN0.DATA[3] * 256 + MessageCAN0.DATA[2]) / 10;
		g_sCarInfo.RINS[0] = (unsigned char)(index >> 8);
		g_sCarInfo.RINS[1] = (unsigned char)(index);

		// ����������¶�
		g_sCarInfo.TMTcon  = MessageCAN0.DATA[4];		
	}

	//
	// ������Ϣ 3
	//
	if(MessageCAN0.CANID == 0x18FEF2A6)	 // ��ȡ��ֵ�¶���Ϣ
   	{

		// ���ת��
		g_sCarInfo.MTSpeed[0] = MessageCAN0.DATA[1];
		g_sCarInfo.MTSpeed[1] = MessageCAN0.DATA[0];

		//1��
		g_sBat1SInfo.MTSpeed[0] = MessageCAN0.DATA[1];
		g_sBat1SInfo.MTSpeed[1] = MessageCAN0.DATA[0];

		// ���ת��
		g_sCarInfo.MTTorque[0] = MessageCAN0.DATA[3];
		g_sCarInfo.MTTorque[1] = MessageCAN0.DATA[2];

		// ����������������
		g_sCarInfo.IMTcon[0] = MessageCAN0.DATA[5];
		g_sCarInfo.IMTcon[1] = MessageCAN0.DATA[4];		
	}
    
    

	//
	// �����ѹ
	//
	if((MessageCAN0.CANID & 0x0000ffff) == 0x000028f3 )
	{
		Cell_Vtg1 =  ((MessageCAN0.DATA[1] << 8  | MessageCAN0.DATA[0]) & 0x0fff) * 10;
		Cell_Vtg2 =  ((MessageCAN0.DATA[3] << 8  | MessageCAN0.DATA[2]) & 0x0fff) * 10;
		Cell_Vtg3 =  ((MessageCAN0.DATA[5] << 8  | MessageCAN0.DATA[4]) & 0x0fff) * 10;
		Cell_Vtg4 =  ((MessageCAN0.DATA[7] << 8  | MessageCAN0.DATA[6]) & 0x0fff) * 10;

		CanID = (MessageCAN0.CANID >> 16) & 0x0f;

		CurrentCase = (MessageCAN0.DATA[1] & 0xf0 ) >> 4;

		if(Cell_Vtg1 > 0)
		{
			CurrentCase = (MessageCAN0.DATA[1] & 0xf0 ) >> 4;

			g_sCellInfo.CellVtg[CaseEndable[CurrentCase - 1] + CanID * 8] 	  = (unsigned char)(Cell_Vtg1 >> 8);
			g_sCellInfo.CellVtg[CaseEndable[CurrentCase - 1] + CanID * 8 + 1] = (unsigned char)(Cell_Vtg1);
		

			if(Cell_Vtg2 > 0)
			{
				g_sCellInfo.CellVtg[CaseEndable[CurrentCase - 1] + CanID * 8 + 2] = (unsigned char)(Cell_Vtg2 >> 8);
				g_sCellInfo.CellVtg[CaseEndable[CurrentCase - 1] + CanID * 8 + 3] = (unsigned char)(Cell_Vtg2);
			}

			if(Cell_Vtg3 > 0)
			{
				g_sCellInfo.CellVtg[CaseEndable[CurrentCase - 1] + CanID * 8 + 4] = (unsigned char)(Cell_Vtg3 >> 8);
				g_sCellInfo.CellVtg[CaseEndable[CurrentCase - 1] + CanID * 8 + 5] = (unsigned char)(Cell_Vtg3);
			}

			if(Cell_Vtg4 > 0)
			{
				g_sCellInfo.CellVtg[CaseEndable[CurrentCase - 1] + CanID * 8 + 6] = (unsigned char)(Cell_Vtg4 >> 8);
				g_sCellInfo.CellVtg[CaseEndable[CurrentCase - 1] + CanID * 8 + 7] = (unsigned char)(Cell_Vtg4);
			}
		}
		
	}

	//
	// �����¶�
	//
	if((MessageCAN0.CANID & 0x0000ffff) == 0x000028f4 )
	{

		CanID = (MessageCAN0.CANID >> 16) & 0x0f;

		if(CanID < 8)
		{
			g_sCellInfo.CaseTemp[CaseEndable[CanID] / 2 + 0] =  MessageCAN0.DATA[0];
			g_sCellInfo.CaseTemp[CaseEndable[CanID] / 2 + 1] =  MessageCAN0.DATA[1];
			g_sCellInfo.CaseTemp[CaseEndable[CanID] / 2 + 2] =  MessageCAN0.DATA[2];
			g_sCellInfo.CaseTemp[CaseEndable[CanID] / 2 + 3] =  MessageCAN0.DATA[3];
		}

		
		
	}



}

void GetAvg(void)
{
	
	NomalVtg =  (g_sExtremInfo.TotalVtg[0] * 256 + g_sExtremInfo.TotalVtg[1]) * 100 / TOTAL_CELL;
																		

	g_sExtremInfo.NomVtgCell[0] = (unsigned char)(NomalVtg >> 8);
	g_sExtremInfo.NomVtgCell[1] = (unsigned char)(NomalVtg);

	NomalVtg = 0;

	g_sExtremInfo.NomTemp	= (	g_sExtremInfo.MaxTemp[1] + g_sExtremInfo.MinTemp[1]) / 2 ;
	//1S
	g_sBat1SInfo.OutTemp	= (	g_sExtremInfo.MaxTemp[1] + g_sExtremInfo.MinTemp[1]) / 2 ;
	g_sBat1SInfo.AverTemp[1]	= g_sBat1SInfo.OutTemp;
	g_sBat1SInfo.AverTemp[0]	= 0x00;

	g_sExtremInfo.TempSub = g_sExtremInfo.MaxTemp[1] - g_sExtremInfo.MinTemp[1];

	

	NomTemp = g_sExtremInfo.MaxVtgCell[2] * 256 + g_sExtremInfo.MaxVtgCell[3] - 
					  g_sExtremInfo.MinVtgCell[2] * 256 - g_sExtremInfo.MinVtgCell[3];

	g_sExtremInfo.VtgSub[0] = (unsigned char)(NomTemp >> 8);
	g_sExtremInfo.VtgSub[1] = (unsigned char)NomTemp;

	NomTemp = 0;

	g_sExtremInfo.TempSub = g_sExtremInfo.MaxTemp[1] - g_sExtremInfo.MinTemp[1];
}
