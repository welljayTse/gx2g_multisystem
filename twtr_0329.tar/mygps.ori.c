#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

#include "gx4g.h"

	
//unsigned char gs_gpsrecvtmp[256] = {0};
//unsigned char gs_gpsrecvdata[256] = {0};
//unsigned char gs_gpsrecvbuf[256] = {0};


/*
void gps_init()
{
        unsigned char cmd[256];

	bzero(cmd, 256);
	sprintf(cmd, "%s", "/opt/gpsinfo_get.sh");
	system(cmd);
	usleep (100000);
}
*/

unsigned char get_complet_prame()
{

	int flag =0;
	int i;
        int fd =0;

	fd = open ("/dev/ttyUSB3",O_RDWR);
	while(1){
		memset(psh->gs_gpsrecvtmp,0,sizeof(psh->gs_gpsrecvtmp));
		if (read(fd,psh->gs_gpsrecvtmp,sizeof(psh->gs_gpsrecvtmp))>0){
			//printf("readtmp:%s\n",read_tmp);
			for (i=0;i<strlen(psh->gs_gpsrecvtmp);i++){
				if (psh->gs_gpsrecvtmp[i]=='$'){
					memset(psh->gs_gpsrecvdata,0,sizeof(psh->gs_gpsrecvdata));
					char tmp[5]={0};
					tmp[0]=psh->gs_gpsrecvtmp[i];
					strcat(psh->gs_gpsrecvdata,tmp);
				}
				else if(psh->gs_gpsrecvtmp[i]=='*'){
					char tmp[5]={0};
					tmp[0]=psh->gs_gpsrecvtmp[i];
					strcat(psh->gs_gpsrecvdata,tmp);
					
					memcpy(psh->gs_gpsrecvbuf,psh->gs_gpsrecvdata,sizeof(psh->gs_gpsrecvdata));
					break;
				}
				else {
				        char tmp[5]={0};
					tmp[0]=psh->gs_gpsrecvtmp[i];
					strcat(psh->gs_gpsrecvdata,tmp);
				}
	
				//	printf("gpsrecvbuf= %s\n",psh->gs_gpsrecvbuf );
			}
			return 1;
		}
	}
	close(fd);
}

/*
unsigned char get_complet_prame()
{

	int flag =0;
	int i;
        int fd =0;

	fd = open ("/dev/ttyUSB3",O_RDWR);
	while(1){
		memset(psh->gs_gpsrecvtmp,0,sizeof(psh->gs_gpsrecvtmp));
		if (read(fd,psh->gs_gpsrecvtmp,sizeof(psh->gs_gpsrecvtmp))>0){
			//printf("readtmp:%s\n",read_tmp);
			for (i=0;i<strlen(psh->gs_gpsrecvtmp);i++){
				if (psh->gs_gpsrecvtmp[i]=='$'){
					memset(psh->gs_gpsrecvdata,0,sizeof(psh->gs_gpsrecvdata));
					char tmp[5]={0};
					tmp[0]=psh->gs_gpsrecvtmp[i];
					strcat(psh->gs_gpsrecvdata,tmp);
				}
				else if(psh->gs_gpsrecvtmp[i]=='*'){
					char tmp[5]={0};
					tmp[0]=psh->gs_gpsrecvtmp[i];
					strcat(psh->gs_gpsrecvdata,tmp);
					flag=1;
					
					memcpy(psh->gs_gpsrecvbuf,psh->gs_gpsrecvdata,sizeof(psh->gs_gpsrecvdata));
				}
				else {
				        char tmp[5]={0};
					tmp[0]=psh->gs_gpsrecvtmp[i];
					strcat(psh->gs_gpsrecvdata,tmp);
				}
	
				//	printf("gpsrecvbuf= %s\n",psh->gs_gpsrecvbuf );
			
			}
			if(flag == 1){
			        close(fd);
				return 1;
			}
			else{
				close(fd);
				return 0;
			}
		}
	}
}
*/


/*********************************************************************************************************
** Function name:       GpsInfoGet
** Descriptions:        ��ȡGPS��Ϣ
** input parameters:    ��
** output parameters:   ��ȡ��ɷ��� 1   ��ȡʧ�ܷ��� 0
** Returned value:      ��
*********************************************************************************************************/
//          time    status  lat          	 log               spd     cog     date
//$ GPRMC , 083559.00 , A , 4717.11437 , N , 00833.91522 , E , 0.004 , 77.52 , 091202 ,,,A*57


unsigned char gpsinfoget()
{
	unsigned char i; 
	unsigned char *ptr;
	unsigned char *index;
	unsigned short temp;

	psh->gs_gpsinfo_recv.len = 18;
        
        get_complet_prame();
      
//	char * psh->gs_gpsrecvbuf = "$GPRMC,084100.0,A,3154.576498,N,11722.141770,E,0.0,,010616,0.0,E,A*27";
        
	printf ("psh->gs_gpsrecvbuf = %s\n",psh->gs_gpsrecvbuf);

	ptr = (unsigned char *)strstr((unsigned char *)psh->gs_gpsrecvbuf,(unsigned char *)"GPRMC");
	//ptr = (unsigned char *)strstr((const char *)psh->gs_gpsrecvbuf,(const char *)"GPRMC");
        
        printf ("\n ptr = %s\n",ptr);

	if(NULL == ptr)
	{
		return 0;
	}


//	for (i=0;i<68;i++){
//		printf("gps recv buf[%d] =%c \n",i,psh->gs_gpsrecvbuf[i]);
//	}
//	printf("psh->gs_gpsrecvbuf[ptr - psh->gs_gpsrecvbuf + 16]=%c \n", psh->gs_gpsrecvbuf[ptr - psh->gs_gpsrecvbuf + 16]);

//	if(psh->gs_gpsrecvbuf[ptr - psh->gs_gpsrecvbuf + 16] == 'A')
//

	if(psh->gs_gpsrecvbuf[16] == 'A'){

                printf("\n GPRMC get it \n ");

                psh->gs_gpsinfo_recv.len = 18; 

		// GPS ʱ��
		ptr = (unsigned char *)strstr((const char *)psh->gs_gpsrecvbuf,",") + 1;
		psh->gs_gpsinfo_recv.time[3]   = (*ptr - '0') * 10 + (*(ptr+1) - '0');	     // ʱ
		psh->gs_cellinfo_recv.time[3]  = psh->gs_gpsinfo_recv.time[3];	    				 // ʱ
		psh->gs_extrminfo_recv.time[3] = psh->gs_gpsinfo_recv.time[3];					 // ʱ

		psh->gs_gpsinfo_recv.time[4]   = (*(ptr+2) - '0') * 10 + (*(ptr+3) - '0');  // ��
		psh->gs_cellinfo_recv.time[4]  = psh->gs_gpsinfo_recv.time[4];	    				 // ��
		psh->gs_extrminfo_recv.time[4] = psh->gs_gpsinfo_recv.time[4];
		// ��
		psh->gs_gpsinfo_recv.time[5]   = (*(ptr+4) - '0') * 10 + (*(ptr+5) - '0');  // ��
		psh->gs_cellinfo_recv.time[5]  = psh->gs_gpsinfo_recv.time[5];	    				 // ��
		psh->gs_extrminfo_recv.time[5] = psh->gs_gpsinfo_recv.time[5];						 // ��

		//g_ucGPSInfo[0] = 0;

		// GPS γ��
		//          time    status  lat          	 log               spd     cog     date
		//$ GPRMC , 083559.00 , A , 4717.11437 , N , 00833.91522 , E , 0.004 , 77.52 , 091202 ,,,A*57
		ptr = (unsigned char *)strstr((const char *)ptr,",");
		ptr = (unsigned char *)strstr((const char *)(ptr+1),",") + 1;
		if(*(ptr+11) == 'S')
		{
			psh->gs_gpsinfo_recv.lat[0] = 0x01;
		}
		else
		{
			psh->gs_gpsinfo_recv.lat[0] = 0x00;
		}
		psh->gs_gpsinfo_recv.lat[1] = (*ptr - '0') * 10 + *(ptr+1) - '0';	
			
		temp = 	(*(ptr+2) - '0') * 10000 + 
				(*(ptr+3) - '0') * 1000 + 
				(*(ptr+5) - '0') * 100 + 
				(*(ptr+6) - '0') * 10 + 
				(*(ptr+7) - '0');
												  
		psh->gs_gpsinfo_recv.lat[2] = (unsigned char)(temp >> 8);									  
		psh->gs_gpsinfo_recv.lat[3] = (unsigned char)temp ;
	

		// GPS ����
		ptr = (unsigned char *)strstr((const char *)ptr,",");
		ptr = (unsigned char *)strstr((const char *)(ptr+1),",") + 1;
		if(*(ptr+12) == 'W')
		{
		 	psh->gs_gpsinfo_recv.lon[0] = 0x01;
		}
		else
		{
			psh->gs_gpsinfo_recv.lon[0] = 0x00;
		}
		psh->gs_gpsinfo_recv.lon[1] = ((*ptr - '0') * 100 + (*(ptr+1) - '0') * 10 + *(ptr+2) - '0');	
			
		temp = 	(*(ptr+3) - '0') * 10000 + 
				(*(ptr+4) - '0') * 1000 + 
				(*(ptr+6) - '0') * 100 + 
				(*(ptr+7) - '0') * 10 + 
				(*(ptr+8) - '0');
					  
		psh->gs_gpsinfo_recv.lon[2] = (unsigned char)(temp >> 8);									  
		psh->gs_gpsinfo_recv.lon[3] = (unsigned char)temp;

     		// GPS �ٶ�
		ptr   = (unsigned char *)strstr((const char *)ptr,",");
		ptr   = (unsigned char *)strstr((const char *)(ptr+1),",") + 1;
		index = (unsigned char *)strstr((const char *)(ptr+1),".");

		switch(index - ptr)
		{
			case 1:
				psh->gs_gpsinfo_recv.spd[1] = *ptr - '0';
				break;

			case 2:
				psh->gs_gpsinfo_recv.spd[1] = (*ptr - '0') * 10 + (*(ptr+1)- '0');
				break;

			case 3:
				psh->gs_gpsinfo_recv.spd[1] = (*ptr - '0') * 100 + (*(ptr+1)- '0') * 10 + *(ptr+2)- '0';
				break;

			default:
				psh->gs_gpsinfo_recv.spd[1] = 0;
				break;
		}


		ptr = (unsigned char *)strstr((const char *)ptr,",")+1;
		index = (unsigned char *)strstr((const char *)(ptr+1),".");
		 
		switch(index - ptr)
		{
			case 1:
				psh->gs_gpsinfo_recv.cog[0] = 0;
				psh->gs_gpsinfo_recv.cog[1] = *ptr - '0';
				break;

			case 2:
				psh->gs_gpsinfo_recv.cog[0] = 0;
				psh->gs_gpsinfo_recv.cog[1] = (*ptr - '0') * 10 + (*(ptr+1)- '0');
				break;

			case 3:
				temp = 	(*ptr - '0') * 100 + (*(ptr+1)- '0') * 10 + *(ptr+2)- '0';
				psh->gs_gpsinfo_recv.cog[1] = (unsigned char)temp ;
				psh->gs_gpsinfo_recv.cog[0] = (unsigned char)(temp >> 8);
				break;

			default:
				psh->gs_gpsinfo_recv.cog[0] = 0x00;
				psh->gs_gpsinfo_recv.cog[1] = 0x00;
				break;
		}

		ptr = (unsigned char *)strstr((const char *)ptr,(const char *)(",")) + 1;
		psh->gs_gpsinfo_recv.time[2]   = (*ptr - '0') * 10 + (*(ptr+1) - '0');	    // ��
		psh->gs_cellinfo_recv.time[2]  = psh->gs_gpsinfo_recv.time[2];	    				// ��
		psh->gs_extrminfo_recv.time[2] = psh->gs_gpsinfo_recv.time[2];						// ��

		psh->gs_gpsinfo_recv.time[1]   = (*(ptr+2) - '0') * 10 + (*(ptr+3) - '0'); // ��
		psh->gs_cellinfo_recv.time[1]  = psh->gs_gpsinfo_recv.time[1];	    				// ��
		psh->gs_extrminfo_recv.time[1] = psh->gs_gpsinfo_recv.time[1];	
		
		psh->gs_gpsinfo_recv.time[0]   = (*(ptr+4) - '0') * 10 + (*(ptr+5) - '0'); // ��	
		psh->gs_cellinfo_recv.time[0]  = psh->gs_gpsinfo_recv.time[0];	    				// ��
		psh->gs_extrminfo_recv.time[0] = psh->gs_gpsinfo_recv.time[0];						// ��

         	memcpy(&psh->gs_gpsinfo_send, &psh->gs_gpsinfo_recv, sizeof(gps_info));
                printf("gpsinfo read sending!!!!\n");
		return 1;
	}
	else
	{
		for(i = 0 ; i < 26 ; i++)
		{
	//		psh->gs_gpsinfo_send[i] = 0xff;
		}

		return 0;
	}

}
